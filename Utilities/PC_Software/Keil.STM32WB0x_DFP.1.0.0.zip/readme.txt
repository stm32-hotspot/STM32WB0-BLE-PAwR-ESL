/ **
  ***********************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WB0x devices support on MDK-ARM.
  ***********************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ************************************************************************************************/
  
  Running the "Keil.STM32WB0x_DFP.1.0.0.pack" adds the following:
  ===============================================================================================================================
	1. Part numbers for  :
	 - Product lines: STM32WB09xExx/STM32WB07xCxx/STM32WB06xCxx/STM32WB05xZxx

	2. Automatic STM32WB0x flash algorithm selection 
		
	3. Update SVD files: STM32WB09, STM32WB07, STM32WB06 & STM32WB05.


  How to use:
  ===============================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
	 
	* Double Clic on  "Keil.STM32WB0x_DFP.1.0.0.pack" in order to install this pack in 
	  the Keil install directory.
	  
    PS: Please make sure that you are using PackUnzip.exe to run this pack.

  SVD files ReleaseNotes:
  ===============================================================================================================================
    =======================================================
	STM32WB05_v0r1:     initial release
	=======================================================
	Derived from WB09

	=======================================================
	STM32WB05_v0r2:     seconde release
	=======================================================
	Doc ID: RM0491- Rev 1 - April 2022

	Derived from IPxact 
	- Complete support for IPs

	=======================================================
	STM32WB05_v0r3:     
	=======================================================
	Doc ID: RM0491- Rev 1 - April 2022

	Adding IP_radio
	Update in interrupts

	#Update in license section

	=======================================================
	STM32WB05_v0r4:     
	=======================================================
	Doc ID: RM0491- Rev 1 - April 2022

	Update in ADC, Flash, PWRC, System Control, RCC, TIM2 and TIM16

	#Update in CPU section
	
	=======================================================
	STM32WB09_v0r1:     initial release
	=======================================================
	Doc ID: RM0505 - Rev 0.1 - 29 September 2023
	Spirit3

	IPs Derived from XML files on sharepoint

	- Complete support for interrupts -


	=======================================================
	STM32WB09_v0r2:     seconde release
	=======================================================
	Doc ID: RM0505 - Rev 0.1 - 29 September 2023

	Derived from IPxact:

	- Complete support for IPs

	=======================================================
	STM32WB09_v0r3:     
	=======================================================
	Doc ID: RM0505 - Rev 0.1 - 29 September 2023

	Adding IP_radio
	Update in interrupts

	#Update in license section
		  
	=======================================================
	STM32WB09_v0r4:     
	=======================================================
	Doc ID: RM0505 - Rev 0.1 - 29 September 2023

	Update in ADC, Flash, PWRC, System Control, RCC, TIM2 and TIM16

	#Update in CPU section
	
	=======================================================
	STM32WB07_v0r1:     initial release
	=======================================================
	Derived from WB09

	=======================================================
	STM32WB07_v0r2:     seconde release
	=======================================================
	Derived from WB09

	=======================================================
	STM32WB07_v0r3:     
	=======================================================
	Doc ID: RM0479 - Rev 3 - April 2022

	-Adding support IP_radio
	-Update in interrupts
	-Complete support for IPs

	#Update in license section

	=======================================================
	STM32WB07_v0r4:     
	=======================================================
	Doc ID: RM0479 - Rev 3 - April 2022

	-Update in RCC, BLUE and System Control 

	#Update in CPU section
	=======================================================
	STM32WB06_v0r1:     initial release
	=======================================================

	Derived from STM32WB07_v0r2

	=======================================================
	STM32WB06_v0r2:     
	=======================================================
	Derived from STM32WB07_v0r3

	-Adding support IP_radio
	-Update in interrupts
	-Complete support for IPs

	=======================================================
	STM32WB06_v0r3:     
	=======================================================
	Derived from STM32WB07_v0r4:

	-Update in RCC, BLUE and System Control 

	#Update in CPU section





	



